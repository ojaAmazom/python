# level4.txtへ「大原太郎」と書き込むように修正してください
f = open("level4.txt", "r")
f.write("私の名前は大原太郎です")
f.close
input("")