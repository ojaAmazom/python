# バグを修正してください。
suuti_list = (100, 200, 300)
suuti_list[0] += 300
print(suuti_list[0])