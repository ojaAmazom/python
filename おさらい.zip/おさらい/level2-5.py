# バグを修正してください
def kansu():
    print(name)


name = input("名前を入力してください：")
kansu(name)