# バグを修正してprint関数が実行されるようにしてください
kansu
def kansu():
    print("あなたの名前は太郎です")