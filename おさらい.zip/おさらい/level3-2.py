# 101と画面に出力されるように修正してください
# ただしプログラムの行数を増やさないでください
# また、変数の値は修正しないでください
def kansu(suuti):
    one = 1
    hundred = 100
    def kansu2(suuti):
        suuti * suuti
    def kansu3(suuti):
        suuti - hundred
    suuti + one

suuti = 110
print(kansu(suuti))