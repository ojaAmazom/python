# 111と画面に出力されるように修正してください
# ただし10行目と11行目は修正しないでください
def kansu(suuti):
    def kansu2(suuti):
        suuti * suuti
    def kansu3(suuti):
        suuti - 100
    suuti + 1

suuti = 110
print(kansu(suuti))