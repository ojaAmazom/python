# バグを修正し全ての名前を一度ずつ順番に出力できるようにしてください
name_list = ["太郎", "次郎", "三郎", "四郎", "五郎"]
for i in range(1, 5):
    print(name_list)
