# level4.txtから「大原太郎」と読み込み画面に出力するように修正してください
f = open("level4.txt", "r")
print(f.readline())
f.close
input("")