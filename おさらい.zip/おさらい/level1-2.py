# 「大原 太郎」と出力するようにバグを修正してください。
last_name = "大原"
first_name = "太郎"
print(last_name first_name)