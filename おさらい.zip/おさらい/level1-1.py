# バグを修正しOKと出力するようにしてください。
my_hensu = 12345
if my_hensu = 12345:
    print("OK")