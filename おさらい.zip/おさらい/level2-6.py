# バグを修正してください。ただし修正してよいのは1行のみです。
def kansu(na):
    print(na)


name = input("名前を入力してください：")
kansu()